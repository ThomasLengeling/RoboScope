# Interaction Mode


- Included visualization of shape files and simulations.
- Connected to the CityIO Protocol.

## v0.2

- Push and Pull interface for the rod

## v0.1

- Neo Pixels 4 LEDs RGBW.
- Simple Rod Up and Down.
