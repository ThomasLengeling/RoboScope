Simple CAN interface
http://henrysbench.capnfatz.com/henrys-bench/arduino-projects-tips-and-more/build-an-arduino-can-transceiver/

Teensy CAN BUS:

CAN BUS eagle:
https://github.com/dmavromatis/mavroOBD/

https://www.seeedstudio.com/Serial-CAN-BUS-Module-based-on-MCP2551-and-MCP2515.html

http://www.industrialberry.com/canberry-v-2-0/


https://harrisonsand.com/static/CAN_module.pdf
