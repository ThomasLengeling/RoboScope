#include "Block.h"

//----------------------------------------
void Block::draw(){
  ofDrawBox(mPos, mWidth, mHeight, mDepth);
}

//----------------------------------------
void Block::update(){

}


//----------------------------------------
void Block::setPos(glm::vec2 pos){

}

//----------------------------------------
void Block::setSize(glm::vec3 mSize){

}

//----------------------------------------
void Block::setColor(ofColor col){

}
