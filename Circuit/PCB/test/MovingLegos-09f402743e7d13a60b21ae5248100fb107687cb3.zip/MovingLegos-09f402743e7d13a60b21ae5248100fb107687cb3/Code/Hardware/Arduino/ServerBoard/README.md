## READ ME

The servoBoardTest.ino script is meant to be used as a tester script for the ClientBoard script. It tests the CAN Bus communication and message interpretation for the ClientBoard.
