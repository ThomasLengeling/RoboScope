/*
   Class that manages CAN Bus Communication protocol
*/
#ifndef SERIAL_PARSER_H
#define SERIAL_PARSER_H






//---------------------------------------------------------
class SerialParser {
  public:
    //constructor

    SerialParser(){
       
    }

    void read(){
      
    }

    
    
  private:
};

#endif
