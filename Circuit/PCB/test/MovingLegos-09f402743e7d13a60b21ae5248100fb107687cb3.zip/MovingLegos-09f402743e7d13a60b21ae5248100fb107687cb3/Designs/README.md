# Design files

Core

Fusion 360


## v.02

### Base

- Adjust spacing of the holes of the base
- Adjust the base for each motor, opening for each motor, cable pass for each motors

## Aesthetics

- Box design

### Interface Box

- Redesign the box
